CINEBOX — ANDROID PWA PACKAGE

Files:
- index.html: your CineBox website
- manifest.webmanifest: install/app metadata
- sw.js: app-shell service worker (online-first)
- icons/: app icons

IMPORTANT:
1. This package must be hosted on an HTTPS website for Android Chrome installation.
2. Open the hosted URL in Chrome on Android.
3. Tap ⋮ > Install app (or Add to Home screen) and confirm.
4. CineBox still needs an internet connection for its online movie catalogue/player and external libraries.
5. The service worker only caches the app shell; it does not download or store movies.

Suggested easy hosting:
- GitHub Pages or another static HTTPS host.
- Upload the CONTENTS of this folder, not the ZIP file itself, to the host's site/root folder.
